/**
 * 127HUB AI - In-Browser JSZip Engine
 * Lightweight, high-performance ZIP builder with native CompressionStream DEFLATE.
 */
(function (global) {
  "use strict";

  // CRC-32 Lookup Table
  const CRC_TABLE = (function () {
    const table = new Uint32Array(256);
    for (let i = 0; i < 256; i++) {
      let c = i;
      for (let k = 0; k < 8; k++) {
        c = (c & 1) ? (0xedb88320 ^ (c >>> 1)) : (c >>> 1);
      }
      table[i] = c >>> 0;
    }
    return table;
  })();

  function calculateCRC32(uint8Array) {
    let crc = 0xffffffff;
    for (let i = 0; i < uint8Array.length; i++) {
      crc = (crc >>> 8) ^ CRC_TABLE[(crc ^ uint8Array[i]) & 0xff];
    }
    return (crc ^ 0xffffffff) >>> 0;
  }

  // Text encoder
  const textEncoder = new TextEncoder();

  function toUint8(data) {
    if (data instanceof Uint8Array) return data;
    if (typeof data === "string") return textEncoder.encode(data);
    if (data instanceof ArrayBuffer) return new Uint8Array(data);
    if (ArrayBuffer.isView(data)) return new Uint8Array(data.buffer, data.byteOffset, data.byteLength);
    return textEncoder.encode(String(data || ""));
  }

  // Compress data using native deflate-raw if available
  async function compressDeflate(dataUint8) {
    if (typeof CompressionStream !== "undefined") {
      try {
        const cs = new CompressionStream("deflate-raw");
        const writer = cs.writable.getWriter();
        writer.write(dataUint8);
        writer.close();
        const reader = cs.readable.getReader();
        const chunks = [];
        let totalLen = 0;
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          chunks.push(value);
          totalLen += value.length;
        }
        const compressed = new Uint8Array(totalLen);
        let offset = 0;
        for (const chunk of chunks) {
          compressed.set(chunk, offset);
          offset += chunk.length;
        }
        // Only use compressed if smaller
        if (compressed.length < dataUint8.length) {
          return { data: compressed, method: 8 };
        }
      } catch (e) {}
    }
    return { data: dataUint8, method: 0 };
  }

  class JSZip {
    constructor() {
      this.files = new Map();
    }

    file(path, content, options = {}) {
      if (!path) return this;
      // Normalize slashes
      const cleanPath = path.replace(/\\/g, "/").replace(/^\/+/, "");
      this.files.set(cleanPath, {
        name: cleanPath,
        content: content,
        date: options.date || new Date(),
        comment: options.comment || "",
      });
      return this;
    }

    folder(name) {
      const cleanName = name.replace(/\\/g, "/").replace(/^\/+/, "").replace(/\/+$/, "") + "/";
      this.files.set(cleanName, {
        name: cleanName,
        content: new Uint8Array(0),
        date: new Date(),
        isDir: true,
      });
      return this;
    }

    async generateAsync(options = { type: "blob" }) {
      const fileEntries = [];
      let localHeaderOffset = 0;

      const localParts = [];

      for (const [path, entry] of this.files.entries()) {
        const isDir = entry.isDir || path.endsWith("/");
        const uncompressed = isDir ? new Uint8Array(0) : toUint8(entry.content);
        const crc = isDir ? 0 : calculateCRC32(uncompressed);
        const uncompressedSize = uncompressed.length;

        let compressedData = uncompressed;
        let compressionMethod = 0;

        if (!isDir && uncompressedSize > 0) {
          const compRes = await compressDeflate(uncompressed);
          compressedData = compRes.data;
          compressionMethod = compRes.method;
        }
        const compressedSize = compressedData.length;

        const nameBytes = textEncoder.encode(path);
        const nameLen = nameBytes.length;

        // DOS Time & Date
        const date = entry.date || new Date();
        const dosTime = ((date.getHours() << 11) | (date.getMinutes() << 5) | (date.getSeconds() >> 1)) & 0xffff;
        const dosDate = (((date.getFullYear() - 1980) << 9) | ((date.getMonth() + 1) << 5) | date.getDate()) & 0xffff;

        // Local file header (30 bytes + nameLen)
        const localHeader = new Uint8Array(30 + nameLen);
        const lView = new DataView(localHeader.buffer);

        lView.setUint32(0, 0x04034b50, true); // Local file header signature
        lView.setUint16(4, 20, true);         // Version needed to extract (2.0)
        lView.setUint16(6, 0x0800, true);     // General purpose bit flag (UTF-8)
        lView.setUint16(8, compressionMethod, true); // Compression method
        lView.setUint16(10, dosTime, true);
        lView.setUint16(12, dosDate, true);
        lView.setUint32(14, crc, true);
        lView.setUint32(18, compressedSize, true);
        lView.setUint32(22, uncompressedSize, true);
        lView.setUint16(26, nameLen, true);
        lView.setUint16(28, 0, true);         // Extra field length

        localHeader.set(nameBytes, 30);

        localParts.push(localHeader);
        if (compressedSize > 0) {
          localParts.push(compressedData);
        }

        fileEntries.push({
          path,
          nameBytes,
          crc,
          compressedSize,
          uncompressedSize,
          compressionMethod,
          dosTime,
          dosDate,
          offset: localHeaderOffset,
          isDir,
        });

        localHeaderOffset += localHeader.length + compressedSize;
      }

      // Central directory records
      const centralParts = [];
      let centralDirSize = 0;

      for (const entry of fileEntries) {
        const nameLen = entry.nameBytes.length;
        const cdHeader = new Uint8Array(46 + nameLen);
        const cdView = new DataView(cdHeader.buffer);

        cdView.setUint32(0, 0x02014b50, true); // Central directory file header signature
        cdView.setUint16(4, 20, true);          // Version made by
        cdView.setUint16(6, 20, true);          // Version needed to extract
        cdView.setUint16(8, 0x0800, true);      // General purpose bit flag (UTF-8)
        cdView.setUint16(10, entry.compressionMethod, true);
        cdView.setUint16(12, entry.dosTime, true);
        cdView.setUint16(14, entry.dosDate, true);
        cdView.setUint32(16, entry.crc, true);
        cdView.setUint32(20, entry.compressedSize, true);
        cdView.setUint32(24, entry.uncompressedSize, true);
        cdView.setUint16(28, nameLen, true);
        cdView.setUint16(30, 0, true);          // Extra field length
        cdView.setUint16(32, 0, true);          // File comment length
        cdView.setUint16(34, 0, true);          // Disk number start
        cdView.setUint16(36, 0, true);          // Internal file attributes
        cdView.setUint32(38, entry.isDir ? 0x10 : 0x20, true); // External file attributes
        cdView.setUint32(42, entry.offset, true); // Relative offset of local header

        cdHeader.set(entry.nameBytes, 46);

        centralParts.push(cdHeader);
        centralDirSize += cdHeader.length;
      }

      // End of central directory record (22 bytes)
      const eocd = new Uint8Array(22);
      const eocdView = new DataView(eocd.buffer);

      eocdView.setUint32(0, 0x06054b50, true); // EOCD signature
      eocdView.setUint16(4, 0, true);          // Disk number
      eocdView.setUint16(6, 0, true);          // Disk with start of central directory
      eocdView.setUint16(8, fileEntries.length, true);  // Number of central directory records on this disk
      eocdView.setUint16(10, fileEntries.length, true); // Total number of central directory records
      eocdView.setUint32(12, centralDirSize, true);     // Size of central directory
      eocdView.setUint32(16, localHeaderOffset, true);  // Offset of start of central directory
      eocdView.setUint16(20, 0, true);                  // Comment length

      // Combine all parts into single Blob
      const allParts = [...localParts, ...centralParts, eocd];
      const blob = new Blob(allParts, { type: "application/zip" });

      if (options.type === "uint8array") {
        return new Uint8Array(await blob.arrayBuffer());
      }
      if (options.type === "arraybuffer") {
        return await blob.arrayBuffer();
      }
      return blob;
    }
  }

  global.JSZip = JSZip;
})(typeof window !== "undefined" ? window : typeof self !== "undefined" ? self : this);
